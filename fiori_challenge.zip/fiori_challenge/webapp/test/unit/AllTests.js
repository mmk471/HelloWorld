sap.ui.define([
	"T180/fiori_challenge/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
