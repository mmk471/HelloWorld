sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "T180/fiorichallenge/model/models",
	"sap/ui/core/format/NumberFormat", 
	"sap/ui/core/Fragment"        
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, models, Fragment) {
        "use strict";

        return Controller.extend("T180.fiorichallenge.controller.Main", {
            formatNumber: function (value) {
                var oFloatFormatter = NumberFormat.getFloatInstance({
                    style: "short",
                    decimals: 1
                });
                return oFloatFormatter.format(value);
            },
/*
            onInit: function () {
  			  // create and set JSON Model
              // Instantiate the Asset Review Model from the models.js template
              this.oModel = new JSONModel((models.createAssetReviewModelTemplate()), "AssetReviewModel");
			  this.getView().setModel(this.oModel);
           
              
            },
*/            
            onInit: function () {
                var sDataPath = sap.ui.require.toUrl("T180.fiorichallenge.model") + "/reviewsSummary.json";
                var oModel = new JSONModel(sDataPath);
                this.getView().setModel(oModel, "reviewSummary");            
            },
    

            onExit : function() {
                // destroy the model
                this.oModel.destroy();
            },
    
            getCount: function (aReviews) {
                if (!aReviews || aReviews.length === 0) {
                    return 0;
                }
                var fCount = aReviews.length;
                return fCount.toFixed(0);
    
            }, 
    
            onAfterRendering: function () {

                // Instantiate the Asset Review Model from the models.js template
                //this.getView().setModel(new JSONModel(models.createAssetReviewModelTemplate()), "AssetReviewModel");
 
                // create and set JSON Model
                // Instantiate the Asset Review Model from the models.js template
                
                this.oModel = new JSONModel(models.createAssetReviewModelTemplate());
			    this.getView().setModel(this.oModel, "AssetReviewModel");

                // Example; setting the 'CurrentDate' property in the Asset Review model
                this.getView().getModel("AssetReviewModel").setProperty("/CurrentDate", new Date());
                this.getView().getModel("AssetReviewModel").getProperty("/TotalNumberOfReviews");
                this.getView().getModel("AssetReviewModel").getProperty("/AvgSuitability");
                this.getView().getModel("AssetReviewModel").getProperty("/AvgValue");
                this.getView().getModel("AssetReviewModel").getProperty("/AvgDurability");
                this.getView().getModel("AssetReviewModel").getProperty("/AvgLongevity");

            }, 
        /**
            onOpenDialog : function () {
    
                // create dialog lazily
                if (!this.pDialog) {
                    this.pDialog = this.loadFragment({
                        name: "T180.fiorichallenge.view.ReviewDialog"
                    });
                } 
                this.pDialog.then(function(oDialog) {
                    oDialog.open();
                }               
                );
            },
            onCloseDialog : function () {
                // note: We don't need to chain to the pDialog promise, since this event-handler
                // is only called from within the close dialog itself.
               this.byId("reviewDialog").close();
            },            
        */
            /*
            onSaveDialog : function () {
                var fnSuccess = function () {
                    this._setBusy(false);
                    MessageToast.show(this._getText("changesSentMessage"));
                    this._setUIChanges(false);
                }.bind(this);

                var fnError = function (oError) {
                    this._setBusy(false);
                    this._setUIChanges(false);
                    MessageBox.error(oError.message);
                }.bind(this);    

                this._setBusy(true); // Lock UI until submitBatch is resolved.
                this.getView().getModel().submitBatch("review").then(fnSuccess, fnError);
                this._bTechnicalErrors = false; // If there were technical errors, a new save resets them.
    
                // note: We don't need to chain to the pDialog promise, since this event-handler
                // is only called from within the save dialog itself.
               this.byId("reviewDialog").close();
            } 
            */           


        /**
		    * Lock UI when changing data in the input controls
		    * @param {sap.ui.base.Event} oEvt - Event data
		    */
		    onInputChange : function (oEvt) {
		    	if (oEvt.getParameter("escPressed")) {
		  		this._setUIChanges();
		    	} else {
		  	  	this._setUIChanges(true);
		  	  	// Check if the username in the changed table row is empty and set the appView property accordingly
		  	  	if (oEvt.getSource().getParent().getBindingContext().getProperty("AssetName")) {
		  	  		this.getView().getModel("review").setProperty("/AssetName", false);
		    		}
		    	}
	    	}

        });
    });
