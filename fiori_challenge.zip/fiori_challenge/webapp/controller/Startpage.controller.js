sap.ui.define([
    'sap/ui/core/mvc/Controller',
    "T180/fiorichallenge/model/models"

],

    function (Controller){
	"use strict";

	var PageController = Controller.extend("T180.fiorichallenge.controller.Startpage", {
        formatNumber: function (value) {
			var oFloatFormatter = NumberFormat.getFloatInstance({
				style: "short",
				decimals: 1
			});
			return oFloatFormatter.format(value);
		}       

	});

	return PageController;

});